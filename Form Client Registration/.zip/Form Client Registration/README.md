# PHP simple client registration form

It includes SCRUD for each record and input validation.
